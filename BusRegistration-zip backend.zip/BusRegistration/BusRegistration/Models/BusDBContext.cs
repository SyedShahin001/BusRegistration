﻿using Microsoft.EntityFrameworkCore;
namespace BusRegistration.Models
{
    public class BusDBContext: DbContext

    {
        public BusDBContext(DbContextOptions<BusDBContext> options) :base(options)
            {

        }

        public DbSet<Booking> bookings { get; set; }
        public DbSet<Bus> buses { get; set; }
        public DbSet<Signup> signup { get; set; }
        public DbSet<Review> reviews { get; set; }

        
    }
}
