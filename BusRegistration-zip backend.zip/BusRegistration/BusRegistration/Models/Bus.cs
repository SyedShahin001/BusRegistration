﻿namespace BusRegistration.Models
{
    public class Bus
    {
        public int BusId { get; set; }
        public string BusNumber { get; set; }
        public string BusName { get; set; }
        public string BusDescription { get; set; }
        public string BusURL { get; set; }
        public string Category { get; set; }
        public string Source { get; set; }
        public string Destination { get; set; }
        public DateTime DepartureTime { get; set; }
        public DateTime ArrivalTime { get; set; }
        public double Fare { get; set; }
        public int AvailableSeats { get; set; }
        public string TimeToReach { get; set; }
        public bool BusAvailability { get; set; }


    }
}

