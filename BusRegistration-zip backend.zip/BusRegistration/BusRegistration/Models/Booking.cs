﻿namespace BusRegistration.Models
{
    public class Booking
    {
        public int BookingId { get; set; }
        public int BusId { get; set; }
        public int SignupId { get; set; }
        public string SelectedSeat { get; set; }
        public DateTime BookingTime { get; set; } = DateTime.Now;
        public int NumberOfSeats { get; set; }
        public double TotalFare { get; set; }



    }
}
