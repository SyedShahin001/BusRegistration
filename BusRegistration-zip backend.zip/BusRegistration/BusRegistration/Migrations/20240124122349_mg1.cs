﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BusRegistration.Migrations
{
    /// <inheritdoc />
    public partial class mg1 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "CustomerId",
                table: "bookings",
                newName: "SignupId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "SignupId",
                table: "bookings",
                newName: "CustomerId");
        }
    }
}
