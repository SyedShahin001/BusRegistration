﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace BusRegistration.Migrations
{
    /// <inheritdoc />
    public partial class mg3 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<DateTime>(
                name: "ArrivalTime",
                table: "bookings",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "BlockedSeats",
                table: "bookings",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddColumn<DateTime>(
                name: "DepartureTime",
                table: "bookings",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.CreateIndex(
                name: "IX_bookings_BusId",
                table: "bookings",
                column: "BusId");

            migrationBuilder.AddForeignKey(
                name: "FK_bookings_buses_BusId",
                table: "bookings",
                column: "BusId",
                principalTable: "buses",
                principalColumn: "BusId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_bookings_buses_BusId",
                table: "bookings");

            migrationBuilder.DropIndex(
                name: "IX_bookings_BusId",
                table: "bookings");

            migrationBuilder.DropColumn(
                name: "ArrivalTime",
                table: "bookings");

            migrationBuilder.DropColumn(
                name: "BlockedSeats",
                table: "bookings");

            migrationBuilder.DropColumn(
                name: "DepartureTime",
                table: "bookings");
        }
    }
}
